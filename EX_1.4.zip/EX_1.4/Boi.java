public class Boi extends Animal {
    public String som() {
        return "mugir";
    }
}
