public class Animal {
    public String som() {
        return "Som produzido pelo animal";
    }
}
