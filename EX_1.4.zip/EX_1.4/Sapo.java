public class Sapo extends Animal {
    public String som() {
        return "coaxar";
    }
}
