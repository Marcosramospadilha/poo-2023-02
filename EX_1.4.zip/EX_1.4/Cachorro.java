public class Cachorro extends Animal {
    public String som() {
        return "latir";
    }
}
