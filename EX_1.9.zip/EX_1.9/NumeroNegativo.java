public class NumeroNegativo extends Exception {
    public NumeroNegativo(String mensagem) {
        super(mensagem);
    }
}
